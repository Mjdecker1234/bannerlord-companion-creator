// Stub types for TaleWorlds.ObjectSystem - only used for compilation without the game installed.
// At runtime, the real game DLLs are used instead.
namespace TaleWorlds.ObjectSystem
{
    // Placeholder to ensure namespace is recognized by the compiler
    internal static class _StubMarker { }
}
