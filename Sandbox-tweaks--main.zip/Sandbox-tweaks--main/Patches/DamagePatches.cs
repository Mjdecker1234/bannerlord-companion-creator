using HarmonyLib;
using TaleWorlds.MountAndBlade;
using TaleWorlds.CampaignSystem;
using TaleWorlds.Core;
using SandboxTweaks.Settings;

namespace SandboxTweaks.Patches
{
    [HarmonyPatch(typeof(Agent), "RegisterBlow")]
    public class DamageMultiplierPatch
    {
        static void Prefix(Agent __instance, ref Blow blow)
        {
            var settings = SandboxTweaksSettings.Instance;
            if (settings?.EnableCampaignTweaks != true) return;

            try
            {
                // Blow.AttackerAgent property has been removed in current Bannerlord version
                // This patch requires updating to use new Blow structure or accessing attacker differently
            }
            catch
            {
                // Silently fail to avoid breaking combat
            }
        }
    }
}
